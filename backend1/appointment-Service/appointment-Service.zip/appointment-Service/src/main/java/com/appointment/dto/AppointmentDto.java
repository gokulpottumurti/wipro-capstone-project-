package com.appointment.dto;

import com.appointment.entity.Appointment;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppointmentDto {
    private Long id;

    @NotNull(message = "PatientId is required")
    private Long patientId;

    @NotNull(message = "ProviderId is required")
    private Long providerId;

    @NotNull(message = "Appointment date is required")
    @Future(message = "Appointment date must be in the future")
    private LocalDateTime appointmentDate;

    private String notes;
    private String status; // PENDING, CONFIRMED, COMPLETED, CANCELLED
}

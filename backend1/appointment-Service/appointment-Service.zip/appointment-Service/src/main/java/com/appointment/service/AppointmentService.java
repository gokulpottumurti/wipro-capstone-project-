package com.appointment.service;

import com.appointment.dto.AppointmentDto;
import com.appointment.entity.Appointment;
import com.appointment.repository.AppointmentRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AppointmentService {

    private final AppointmentRepository repository;

    public AppointmentService(AppointmentRepository repository) {
        this.repository = repository;
    }

    public AppointmentDto create(AppointmentDto dto) {
        Appointment appointment = Appointment.builder()
                .patientId(dto.getPatientId())
                .providerId(dto.getProviderId())
                .appointmentDate(dto.getAppointmentDate())
                .notes(dto.getNotes())
                .status(parseStatus(dto.getStatus()))
                .build();
        Appointment saved = repository.save(appointment);
        return toDto(saved);
    }

    public List<AppointmentDto> findAll() {
        return repository.findAll().stream().map(this::toDto).collect(Collectors.toList());
    }

    public Optional<AppointmentDto> findById(Long id) {
        return repository.findById(id).map(this::toDto);
    }

    public List<AppointmentDto> findByPatient(Long patientId) {
        return repository.findByPatientId(patientId).stream().map(this::toDto).collect(Collectors.toList());
    }

    public List<AppointmentDto> findByProvider(Long providerId) {
        return repository.findByProviderId(providerId).stream().map(this::toDto).collect(Collectors.toList());
    }

    public AppointmentDto update(Long id, AppointmentDto dto) {
        Appointment updated = repository.findById(id).map(existing -> {
            existing.setAppointmentDate(dto.getAppointmentDate() != null ? dto.getAppointmentDate() : existing.getAppointmentDate());
            existing.setNotes(dto.getNotes() != null ? dto.getNotes() : existing.getNotes());
            existing.setStatus(parseStatus(dto.getStatus() != null ? dto.getStatus() : existing.getStatus().name()));
            return repository.save(existing);
        }).orElseThrow(() -> new IllegalArgumentException("Appointment not found"));
        return toDto(updated);
    }

    public void delete(Long id) {
        repository.deleteById(id);
    }

    private Appointment.Status parseStatus(String status) {
        if (status == null) return Appointment.Status.PENDING;
        try {
            return Appointment.Status.valueOf(status.toUpperCase());
        } catch (Exception e) {
            return Appointment.Status.PENDING;
        }
    }

    private AppointmentDto toDto(Appointment a) {
        return AppointmentDto.builder()
                .id(a.getId())
                .patientId(a.getPatientId())
                .providerId(a.getProviderId())
                .appointmentDate(a.getAppointmentDate())
                .notes(a.getNotes())
                .status(a.getStatus().name())
                .build();
    }
}
